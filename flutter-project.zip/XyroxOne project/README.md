# XyroxOne — Holographic Core Maximum Glitch V3

This is a visual-focused update to the supplied Flutter project. Existing feature files and route wiring are retained; the holographic overlay is decorative and ignores pointer input.

## Applied visual improvements
- Cyan / electric-blue / violet holographic palette and fine scanlines.
- Brief maximum-glitch bursts with RGB-style echoes and digital tear bands.
- Low-contrast radial energy bloom, orbital node pairs, edge circuit traces, and HUD corner brackets.
- Motion pauses while the app is backgrounded and resumes when foregrounded.
- The overlay respects the platform's reduced-motion / disable-animations preference.
- Effects stay behind an IgnorePointer + ExcludeSemantics layer and do not change authentication or feature logic.

## Verification status
- ZIP integrity: verified after packaging.
- Asset declarations and relative local imports: checked statically for missing paths.
- Flutter analyze, flutter test, and Android APK build: **not run** in this environment because the Flutter/Dart SDK is unavailable. ZIP integrity is not proof that the APK builds. Run `flutter pub get`, `flutter analyze`, `flutter test`, and `flutter build apk --release` in a Flutter-enabled environment before release.

## XyroxOne Audio Experience (added)
- The uploaded video's audio has been extracted and compressed to a stereo MP3 for background music (no video decoding during dashboard playback).
- A shared dashboard audio player loops the music across dashboard feature routes, with play/pause and volume/mute controls.
- Audio pauses when the app is backgrounded and resumes when the app returns if it was playing.
- `audioplayers` was added as a dependency. Run `flutter pub get` before building so `pubspec.lock` is refreshed for the new dependency.

## Follow-up fixes (2026-10-29)
- Fingerprint ring size now scales with the available screen width, with reduced vertical spacing on shorter devices to reduce layout overflow risk.
- Dashboard app bar now displays the bundled `assets/images/logo.png` instead of relying only on a role glyph.
- Splash progress label now describes video playback rather than claiming the app is already ready at 66%; the progress percentage is driven by the actual `splash.mp4` playback position (the supplied clip is approximately 32 seconds).
- When the video cannot initialize, the fallback no longer animates the progress bar to a fake 100% before navigating.
- Flutter/Dart compilation remains unverified in this environment; run the checks above before release.


## Perbaikan layout dan media (29 Oktober 2026)
- Ukuran painter ring sidik jari menggunakan ukuran runtime yang benar (menghindari `const Size` dengan nilai non-konstan).
- Scaffold verifikasi sidik jari tidak mengubah ukuran viewport saat inset sistem muncul.
- Logo dashboard memakai `BoxFit.contain` agar wordmark tidak terpotong pada avatar bulat.
- Splash progress tetap disinkronkan dengan posisi video yang sedang diputar.

Catatan: build APK perlu dijalankan di lingkungan dengan Flutter SDK; arsip ini tidak menyatakan build telah lulus tanpa pengujian tersebut.

## XyroxOne update — Version 2.03

- App/package version aligned to `2.03.0+203` (Android version name `2.03.0`, version code `203`).
- Kept `splash.mp4` as its own silent splash asset; it is not merged with the global background video.
- Kept `splash_music.mp3` as a separate, original audio asset.
- Hardened dashboard music recovery when returning from Android backgrounding/interruption.
- Hardened global background-video pause/resume handling against lifecycle races.
- Existing source files, pages, assets, and dependencies were retained.

Build verification: archive integrity was checked. A Flutter/Dart SDK was not available in the editing environment, so an APK build and device playback test could not be run here.

## XyroxOne 2.03.0 — Background & Audio Stability

- `splash.mp4` is the only video shown during startup and is explicitly muted.
- The global animated background is mounted only after the splash navigates to the dashboard.
- Global/fingerprint/custom background videos are muted and configured with `mixWithOthers` so they do not take audio focus from the MP3 soundtrack.
- The dashboard MP3 remains an independent `AudioPlayer` source with loop mode enabled; it is not merged with any MP4.
- The global background video is rendered behind the dashboard UI and loops continuously. A lightweight watchdog retries playback after transient decoder stalls, and lifecycle resume restarts it when needed.
- The dashboard owns the MP3 player while pushed sub-pages remain above it, so navigating between dashboard tools does not dispose the soundtrack.

Run `flutter pub get`, `flutter analyze`, `flutter test`, then `flutter build apk --release` in a Flutter 3.8.1+ environment to validate the Android build and device playback.


## XyroxOne Version 2.03.1 — Audio & Video Stabilization

- App version updated to `2.03.1+204`.
- Rebuilt `assets/audio/splash_music.mp3` as a genuine MP3 audio-only file (stereo, 44.1 kHz, 192 kbps); the mislabeled MP4 video stream was removed.
- Removed audio streams from `splash.mp4` and `xyroxone_global_background.mp4`; both are now genuinely silent media files, not merely muted in the player.
- Splash uses `BoxFit.contain` so the complete landscape source frame remains visible on portrait phones without cropping its sides.
- Dashboard soundtrack keeps looping independently; an additional six-second watchdog retries playback after unexpected player stops, while respecting manual pause and app backgrounding.
- Global background video retries after a sustained buffering stall (12 seconds), and remains behind the dashboard UI.

Media validation: MP3 stream, silent splash MP4, and silent dashboard background MP4 were checked with `ffprobe`. Flutter static analysis, APK release build, and physical-device playback still require a Flutter-enabled Android environment and have not been claimed as passed.


## Version 2.03.3 — Cyber Glass polish & stability

- Unified the Material 3 theme for cards, navigation, forms, dialogs, controls, and typography.
- Corrected a duplicate `textTheme` argument in the app theme and made text scaling explicitly `double`-typed.
- Kept Orbitron for display headings and Roboto for readable body text.
- Reduced full-screen holographic scan intensity and paused its visual timer when the app is backgrounded or reduced motion is enabled.
- Reduced backdrop blur cost on login, splash, and dashboard surfaces.
- Allowed the app to reach the login screen if Firebase initialization temporarily fails; Firebase-backed features may remain unavailable until connectivity/configuration is restored.
- Preserved authentication, routing, API calls, and existing feature implementations.

Validation note: ZIP integrity and source-level structural checks were run. Flutter SDK was unavailable in this environment, so `flutter analyze`, tests, and release APK build still need to be run on a Flutter-equipped machine.


## XyroxOne 2.03.4 — Custom Background Picker

- Added a wallpaper button at the far-right of the dashboard app bar.
- Users can choose a photo or video from the Android gallery / system photo picker.
- Selected media is copied into the app documents directory and remembered with SharedPreferences.
- Custom videos are muted, looped, and recovered after sustained buffering; soundtrack MP3 remains independent.
- A reset action restores the bundled default dashboard background.
- Uses the existing `image_picker`, `path_provider`, and `shared_preferences` dependencies. No broad gallery/storage permission is required for the Android system picker.


## XyroxOne 2.03.5 — Build fix

- Fixed the nullable `SharedPreferences` background media type passed into `XyroxBackgroundMedia`. The stored type is validated as `image` or `video` before constructing the selection model.
- Version bumped to `2.03.5+208`.


## XyroxOne 2.03.6 — Splash clarity, continuous music & fingerprint hologram
- Removed the splash glass `BackdropFilter` that softened the video beneath the center panel; reduced the dark overlay while retaining text contrast.
- Kept the original 736×414 / 60 fps splash video unchanged to avoid destructive re-encoding or artificial sharpening.
- Started the real MP3 soundtrack on the splash and transferred the same `AudioPlayer` instance to the dashboard, preventing a restart or gap at the transition.
- Kept the splash video muted and the soundtrack independent; dashboard retains its existing loop/recovery/watchdog behavior.
- Added animated holographic orbit arcs, energy particles, and a scan beam to the fingerprint ring. Biometric authentication logic and callbacks were not changed.
- Version bumped to `2.03.6+209`.


## XyroxOne 2.03.7 — Android background music

- Dashboard soundtrack is owned by `audio_service` + `just_audio`, not by the dashboard widget.
- Android runs a media playback foreground service and shows a persistent media notification with Play/Pause/Stop controls.
- Music can continue when the app is sent to the background, the Recents task is dismissed, or the screen is locked (subject to Android/OEM battery restrictions).
- Manual Stop from the media notification stops playback; Play from the dashboard starts it again.
- Powering the phone completely off necessarily stops all playback. Force Stop, uninstall, battery restrictions, and some OEM task-killers can also terminate services.
- Build with `flutter pub get` before `flutter build apk --release`.

## XyroxOne 2.03.7 — Android background music

- Dashboard soundtrack is owned by `audio_service` + `just_audio`, not by the dashboard widget.
- Android runs a media playback foreground service and shows a persistent media notification with Play/Pause/Stop controls.
- Music can continue when the app is sent to the background, the Recents task is dismissed, or the screen is locked, subject to Android/OEM battery restrictions.
- Manual Pause/Stop remains authoritative; the dashboard widget no longer pauses or disposes the app-scoped audio handler when it leaves the foreground or is disposed.
- Powering the phone completely off necessarily stops playback. Android Force Stop, uninstall, battery restrictions, or OEM task-killers can also terminate the service.
- Run `flutter pub get` before `flutter build apk --release` so the new `audio_service` and `just_audio` dependencies are resolved.
