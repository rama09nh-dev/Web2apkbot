import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import 'package:video_player/video_player.dart';

// ═══════════════════════════════════════════════════════════════════
// PALETTE — XYROXONE HOLOGRAPHIC CORE
// ═══════════════════════════════════════════════════════════════════
class _FPC {
  static const bg            = Color(0xFF050A16);
  static const surface       = Color(0xFF0A1426);
  static const card          = Color(0xFF0D1B30);
  static const cardAlt       = Color(0xFF11233B);

  static const border        = Color(0xFF244765);
  static const borderLit     = Color(0xFF3997F5);
  static const primary       = Color(0xFF75CCFF);
  static const primaryMid    = Color(0xFF3997F5);
  static const primaryLight  = Color(0xFFBDEBFF);
  static const accent        = Color(0xFF8B7BFF);

  static const text          = Color(0xFFF2F7FF);
  static const textSub       = Color(0xFFA8BCD2);
  static const textDim       = Color(0xFF71869D);

  static const luxeGrad = LinearGradient(
    colors: [Color(0xFF244765), Color(0xFF3997F5), Color(0xFF8B35FF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const softGrad = LinearGradient(
    colors: [Color(0xFF03050C), Color(0xFF0A1426), Color(0xFF03050C)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const textGrad = LinearGradient(
    colors: [Color(0xFF244765), Color(0xFF3997F5), Color(0xFF8B35FF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );


}

// ═══════════════════════════════════════════════════════════════════
// STATE AUTH
// ═══════════════════════════════════════════════════════════════════
enum _AuthState { idle, scanning, success, failed, unavailable }

// ═══════════════════════════════════════════════════════════════════
// HALAMAN VERIFIKASI SIDIK JARI
// ═══════════════════════════════════════════════════════════════════
class FingerprintVerifyPage extends StatefulWidget {
  final VoidCallback onVerified;
  final VoidCallback? onCancel;
  final Duration duration;
  final String title;
  final String subtitle;

  const FingerprintVerifyPage({
    super.key,
    required this.onVerified,
    this.onCancel,
    this.duration = const Duration(milliseconds: 1800),
    this.title = 'VERIFIKASI SIDIK JARI',
    this.subtitle = 'Scan sidik jari kamu untuk lanjut',
  });

  @override
  State<FingerprintVerifyPage> createState() => _FingerprintVerifyPageState();
}

class _FingerprintVerifyPageState extends State<FingerprintVerifyPage>
    with TickerProviderStateMixin {

  final _auth = LocalAuthentication();

  _AuthState _state = _AuthState.idle;
  String _failMsg   = '';
  double _progress  = 0.0;
  int _attemptCount = 0;
  bool _sensorSupported = false;
  List<BiometricType> _availableBiometrics = <BiometricType>[];
  VideoPlayerController? _backgroundVideoController;
  bool _backgroundVideoReady = false;

  late AnimationController _glowController;
  late AnimationController _rotateController;
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _rotateController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3000),
    )..repeat();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );

    // Video latar dimuat terpisah; jika gagal, UI tetap memakai latar gelap.
    _initBackgroundVideo();

    // Auto-trigger biometrik setelah page siap
    Future.delayed(const Duration(milliseconds: 400), _checkAndAuth);
  }

  @override
  void dispose() {
    _glowController.dispose();
    _rotateController.dispose();
    _pulseController.dispose();
    _backgroundVideoController?.dispose();
    super.dispose();
  }

  Future<void> _initBackgroundVideo() async {
    final controller = VideoPlayerController.asset(
      'assets/videos/fingerprint_background.mp4',
      videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
    );
    _backgroundVideoController = controller;
    try {
      await controller.initialize();
      if (!mounted) {
        await controller.dispose();
        return;
      }
      await controller.setLooping(true);
      await controller.setVolume(0.0); // video latar tidak mengganggu audio aplikasi
      await controller.play();
      if (mounted) setState(() => _backgroundVideoReady = true);
    } catch (_) {
      // Fallback aman: halaman tetap dapat dipakai meskipun video gagal dimuat.
      if (identical(_backgroundVideoController, controller)) {
        _backgroundVideoController = null;
      }
      await controller.dispose();
    }
  }

  Widget _buildVideoBackground() {
    final controller = _backgroundVideoController;
    if (!_backgroundVideoReady ||
        controller == null ||
        !controller.value.isInitialized) {
      return const DecoratedBox(
        decoration: BoxDecoration(gradient: _FPC.softGrad),
      );
    }

    final videoSize = controller.value.size;
    return ClipRect(
      child: FittedBox(
        fit: BoxFit.cover,
        alignment: Alignment.center,
        child: SizedBox(
          width: videoSize.width,
          height: videoSize.height,
          child: VideoPlayer(controller),
        ),
      ),
    );
  }

  // ─── Cek ketersediaan lalu auth ───
  Future<void> _checkAndAuth() async {
    if (!mounted) return;

    try {
      final canCheck  = await _auth.canCheckBiometrics;
      final supported = await _auth.isDeviceSupported();
      final enrolled = await _auth.getAvailableBiometrics();
      if (mounted) {
        setState(() {
          _sensorSupported = canCheck || supported;
          _availableBiometrics = enrolled;
        });
      }

      if (!canCheck && !supported) {
        if (mounted) {
          setState(() {
            _state   = _AuthState.unavailable;
            _failMsg = 'Perangkat tidak mendukung sidik jari';
          });
        }
        return;
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          _state   = _AuthState.unavailable;
          _failMsg = 'Biometrik tidak tersedia di HP ini';
        });
      }
      return;
    }

    await _authenticate();
  }

  // ─── Jalankan autentikasi sidik jari ───
  Future<void> _authenticate() async {
    if (!mounted) return;

    setState(() {
      _state   = _AuthState.scanning;
      _failMsg = '';
      _attemptCount++;
    });

    _pulseController.repeat(reverse: true);
    _animateProgress(to: 0.5);

    try {
      final bool ok = await _auth.authenticate(
        localizedReason: 'Verifikasi sidik jari untuk masuk ke aplikasi',
        options: const AuthenticationOptions(
          stickyAuth: true,
          biometricOnly: false, // bisa fallback ke PIN kalau perlu
        ),
      );

      if (!mounted) return;
      _pulseController.stop();
      _pulseController.reset();

      if (ok) {
        _animateProgress(to: 1.0);
        setState(() => _state = _AuthState.success);
        HapticFeedback.heavyImpact();
        Future.delayed(const Duration(milliseconds: 600), () {
          if (mounted) widget.onVerified();
        });
      } else {
        _animateProgress(to: 0.0);
        setState(() {
          _state   = _AuthState.failed;
          _failMsg = 'Sidik jari tidak dikenali';
        });
        HapticFeedback.vibrate();
      }

    } on PlatformException catch (e) {
      if (!mounted) return;
      _pulseController.stop();
      _pulseController.reset();
      _animateProgress(to: 0.0);

      String msg;
      switch (e.code) {
        case 'NotEnrolled':
          msg = 'Belum ada sidik jari terdaftar di HP ini';
          break;
        case 'LockedOut':
        case 'PermanentlyLockedOut':
          msg = 'Terlalu banyak percobaan gagal, coba nanti';
          break;
        case 'NotAvailable':
          msg = 'Sidik jari tidak tersedia';
          break;
        default:
          msg = 'Verifikasi gagal, coba lagi';
          break;
      }

      setState(() {
        _state   = _AuthState.failed;
        _failMsg = msg;
      });
      HapticFeedback.vibrate();

    } catch (_) {
      if (!mounted) return;
      _pulseController.stop();
      _pulseController.reset();
      _animateProgress(to: 0.0);
      setState(() {
        _state   = _AuthState.failed;
        _failMsg = 'Verifikasi gagal';
      });
    }
  }

  // ─── Animasi progress arc ───
  void _animateProgress({required double to}) {
    final start     = _progress;
    final startTime = DateTime.now();
    const durationMs = 300;

    Timer.periodic(const Duration(milliseconds: 16), (t) {
      if (!mounted) { t.cancel(); return; }
      final elapsed = DateTime.now().difference(startTime).inMilliseconds;
      final factor  = (elapsed / durationMs).clamp(0.0, 1.0);
      setState(() => _progress = start + (to - start) * factor);
      if (elapsed >= durationMs) t.cancel();
    });
  }

  void _showSecurityDetails() {
    String biometricLabel(BiometricType type) {
      switch (type) {
        case BiometricType.fingerprint:
          return 'Sidik jari';
        case BiometricType.face:
          return 'Pengenalan wajah';
        case BiometricType.iris:
          return 'Pemindaian iris';
        case BiometricType.strong:
          return 'Biometrik kuat';
        case BiometricType.weak:
          return 'Biometrik perangkat';
      }
    }

    final methods = _availableBiometrics.map(biometricLabel).toSet().toList();
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (sheetContext) => Container(
        padding: const EdgeInsets.fromLTRB(22, 12, 22, 28),
        decoration: const BoxDecoration(
          color: Color(0xFF0D1B30),
          borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
          border: Border(top: BorderSide(color: _FPC.primary, width: 1.2)),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: _FPC.textDim, borderRadius: BorderRadius.circular(8)))),
              const SizedBox(height: 20),
              const Row(children: [
                Icon(Icons.security_rounded, color: _FPC.primary, size: 24),
                SizedBox(width: 10),
                Text('DIAGNOSTIK KEAMANAN', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
              ]),
              const SizedBox(height: 18),
              _securityDetailRow(Icons.sensors_rounded, 'Dukungan perangkat', _sensorSupported ? 'Terdeteksi' : 'Tidak terdeteksi', _sensorSupported),
              _securityDetailRow(Icons.fingerprint_rounded, 'Metode terdaftar', methods.isEmpty ? 'Tidak terdeteksi / belum diatur' : methods.join(', '), methods.isNotEmpty),
              _securityDetailRow(Icons.replay_rounded, 'Percobaan sesi ini', '$_attemptCount kali', true),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(13),
                decoration: BoxDecoration(color: const Color(0xFF11233B), borderRadius: BorderRadius.circular(14), border: Border.all(color: _FPC.primary.withOpacity(0.25))),
                child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Icon(Icons.privacy_tip_outlined, color: _FPC.primary, size: 19),
                  SizedBox(width: 10),
                  Expanded(child: Text('Verifikasi diproses oleh sistem keamanan Android. Aplikasi tidak membaca atau menyimpan gambar sidik jari kamu.', style: TextStyle(color: _FPC.textSub, height: 1.45, fontSize: 12))),
                ]),
              ),
              const SizedBox(height: 14),
              SizedBox(width: double.infinity, child: OutlinedButton(onPressed: () => Navigator.pop(sheetContext), style: OutlinedButton.styleFrom(foregroundColor: _FPC.primary, side: const BorderSide(color: _FPC.primary), padding: const EdgeInsets.symmetric(vertical: 13)), child: const Text('TUTUP DIAGNOSTIK'))),
            ],
          ),
        ),
      ),
    );
  }

  Widget _securityDetailRow(IconData icon, String title, String value, bool good) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 13),
      child: Row(children: [
        Icon(icon, color: _FPC.primary, size: 19),
        const SizedBox(width: 10),
        Expanded(child: Text(title, style: const TextStyle(color: _FPC.textSub, fontSize: 12))),
        const SizedBox(width: 8),
        Flexible(child: Text(value, textAlign: TextAlign.right, style: TextStyle(color: good ? const Color(0xFF65F4D0) : const Color(0xFFFF7777), fontSize: 11, fontWeight: FontWeight.w700))),
      ]),
    );
  }


  // ─── Batal → ke halaman login ───
  void _goToLogin() {
    widget.onCancel?.call();
    Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    // Ukuran ring mengikuti lebar layar agar tidak memaksa layout melebar.
    final size = math.min(240.0, MediaQuery.sizeOf(context).width * 0.62);

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _goToLogin();
      },
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: _FPC.bg,
        body: Stack(
          fit: StackFit.expand,
          children: [
            // ─── Video latar sinematik; konten tetap di atasnya ───
            Positioned.fill(child: _buildVideoBackground()),
            // Overlay gelap menjaga teks dan indikator sidik jari tetap terbaca.
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.62),
                      const Color(0x99030A16),
                      Colors.black.withOpacity(0.76),
                    ],
                    stops: const [0.0, 0.48, 1.0],
                  ),
                ),
              ),
            ),
            Positioned.fill(
              child: CustomPaint(painter: _FpGridPainter()),
            ),

            SafeArea(
              child: Column(
                children: [
                  // Minimal premium header: navigation arrow intentionally removed.
const Spacer(),

                  // ─── Judul ───
                  AnimatedBuilder(
                    animation: _rotateController,
                    builder: (context, _) {
                      return ShaderMask(
                        shaderCallback: (b) => LinearGradient(
                          begin: Alignment(
                              -1.0 + _rotateController.value * 2, 0.0),
                          end: Alignment(
                              1.0 + _rotateController.value * 2, 0.0),
                          colors: const [
                            Color(0xFF71869D),
                            Color(0xFFFFFFFF),
                            Color(0xFFFFFFFF),
                            Color(0xFFFFFFFF),
                            Color(0xFF71869D),
                          ],
                          stops: const [0.0, 0.3, 0.5, 0.7, 1.0],
                        ).createShader(b),
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(
                            widget.title,
                            maxLines: 1,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Orbitron',
                              letterSpacing: 3,
                              shadows: [
                                Shadow(color: Colors.white, blurRadius: 15),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 12),

                  // ─── Subtitle dinamis per state ───
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: Text(
                      _state == _AuthState.scanning
                          ? 'Tempelkan jari ke sensor...'
                          : _state == _AuthState.success
                              ? 'Terverifikasi!'
                              : _state == _AuthState.failed
                                  ? _failMsg
                                  : _state == _AuthState.unavailable
                                      ? _failMsg
                                      : widget.subtitle,
                      key: ValueKey(_state),
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: _state == _AuthState.success
                            ? const Color(0xFF00FF00)
                            : _state == _AuthState.failed ||
                                    _state == _AuthState.unavailable
                                ? const Color(0xFFFF4444)
                                : _FPC.textSub,
                        fontSize: 13,
                        fontFamily: 'Aktura',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),

                  SizedBox(height: MediaQuery.sizeOf(context).height < 700 ? 18 : 30),

                  // ─── Ring animasi ───
                  AnimatedBuilder(
                    animation: Listenable.merge([
                      _glowController,
                      _rotateController,
                      _pulseController,
                    ]),
                    builder: (context, _) {
                      final glow    = _glowController.value;
                      final rotate  = _rotateController.value;
                      final scanProgress = _state == _AuthState.scanning
                          ? 0.3 + _pulseController.value * 0.45
                          : _progress;
                      final pulse   = _state == _AuthState.scanning
                          ? (0.92 + _pulseController.value * 0.10)
                          : 1.0;

                      return Transform.scale(
                        scale: pulse,
                        child: SizedBox(
                          width: size,
                          height: size,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              // Glow outer
                              Container(
                                width: size,
                                height: size,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: _state == _AuthState.success
                                          ? const Color(0xFF00FF00)
                                              .withOpacity(0.4)
                                          : _state == _AuthState.failed
                                              ? const Color(0xFFFF4444)
                                                  .withOpacity(0.3)
                                              : _FPC.primary.withOpacity(
                                                  0.25 +
                                                      glow * 0.35 +
                                                      scanProgress * 0.4,
                                                ),
                                      blurRadius:
                                          30 + glow * 20 + scanProgress * 30,
                                      spreadRadius: 2 + scanProgress * 4,
                                    ),
                                  ],
                                ),
                              ),

                              // Ring painter
                              CustomPaint(
                                size: Size(size, size),
                                painter: _FingerprintRingPainter(
                                  rotation: rotate * 2 * math.pi,
                                  progress: scanProgress,
                                  stateColor: _state == _AuthState.success
                                      ? const Color(0xFF00FF00)
                                      : _state == _AuthState.failed
                                          ? const Color(0xFFFF4444)
                                          : Colors.white,
                                ),
                              ),

                              // Lapisan hologram: orbit, titik energi, dan scan beam.
                              IgnorePointer(
                                child: CustomPaint(
                                  size: Size(size, size),
                                  painter: _FingerprintHoloPainter(
                                    rotation: rotate * 2 * math.pi,
                                    scan: _pulseController.value,
                                    active: _state == _AuthState.scanning,
                                    color: _state == _AuthState.success
                                        ? const Color(0xFF00FF9D)
                                        : _state == _AuthState.failed ||
                                                _state == _AuthState.unavailable
                                            ? const Color(0xFFFF5C78)
                                            : _FPC.primary,
                                  ),
                                ),
                              ),

                              // Inner circle
                              Container(
                                width: size - 20,
                                height: size - 20,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _FPC.card,
                                  border: Border.all(
                                    color: _FPC.border.withOpacity(
                                      0.5 + glow * 0.4 + scanProgress * 0.5,
                                    ),
                                    width: 2.5,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: _FPC.primary.withOpacity(0.3),
                                      blurRadius: 20,
                                      offset: const Offset(0, 8),
                                    ),
                                  ],
                                ),
                              ),

                              // Icon state transition: fingerprint -> success/failure.
                              AnimatedSwitcher(
                                duration: const Duration(milliseconds: 320),
                                switchInCurve: Curves.easeOutBack,
                                switchOutCurve: Curves.easeIn,
                                transitionBuilder: (child, animation) => FadeTransition(
                                  opacity: animation,
                                  child: ScaleTransition(scale: animation, child: child),
                                ),
                                child: Icon(
                                  _state == _AuthState.success
                                      ? Icons.verified_rounded
                                      : (_state == _AuthState.failed ||
                                              _state == _AuthState.unavailable)
                                          ? Icons.fingerprint_rounded
                                          : Icons.fingerprint_rounded,
                                  key: ValueKey<_AuthState>(_state),
                                  size: size * 0.4,
                                  color: _state == _AuthState.success
                                      ? const Color(0xFF00FF9D)
                                      : (_state == _AuthState.failed ||
                                              _state == _AuthState.unavailable)
                                          ? const Color(0xFFFF5C78)
                                          : _FPC.primary,
                                  shadows: [
                                    Shadow(
                                      color: (_state == _AuthState.success
                                              ? const Color(0xFF00FF9D)
                                              : (_state == _AuthState.failed ||
                                                      _state == _AuthState.unavailable)
                                                  ? const Color(0xFFFF5C78)
                                                  : _FPC.primary)
                                          .withOpacity(0.7 + glow * 0.3),
                                      blurRadius: 20 + scanProgress * 20,
                                    ),
                                  ],
                                ),
                              ),

                              // Persentase / status
                              Positioned(
                                bottom: size * 0.10,
                                child: AnimatedSwitcher(
                                  duration: const Duration(milliseconds: 300),
                                  child: _state == _AuthState.scanning
                                      ? Text(
                                          '${(scanProgress * 100).toInt()}%',
                                          key: const ValueKey('pct'),
                                          style: const TextStyle(
                                            color: _FPC.primary,
                                            fontSize: 16,
                                            fontWeight: FontWeight.w900,
                                            fontFamily: 'Orbitron',
                                            letterSpacing: 1,
                                            shadows: [
                                              Shadow(
                                                color: Colors.white,
                                                blurRadius: 10,
                                              ),
                                            ],
                                          ),
                                        )
                                      : const SizedBox.shrink(
                                          key: ValueKey('empty'),
                                        ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),

                  const SizedBox(height: 30),

                  // ─── Status bar bawah ring ───
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: _buildStatusChip(),
                  ),

                  const Spacer(),

                  // ─── Tombol aksi ───
                  _buildActionButtons(),

                  SizedBox(height: MediaQuery.sizeOf(context).height < 700 ? 16 : 28),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusChip() {
    String label;
    switch (_state) {
      case _AuthState.scanning:
        label = 'MEMINDAI...';
        break;
      case _AuthState.success:
        label = 'BERHASIL ✓';
        break;
      case _AuthState.failed:
        label = 'GAGAL — COBA LAGI';
        break;
      case _AuthState.unavailable:
        label = 'SIDIK JARI TIDAK TERSEDIA';
        break;
      case _AuthState.idle:
        label = 'SIAP MEMINDAI';
        break;
    }

    return Container(
      key: ValueKey(_state),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: BoxDecoration(
        color: _FPC.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: _state == _AuthState.success
              ? const Color(0xFF00FF00)
              : _state == _AuthState.failed || _state == _AuthState.unavailable
                  ? const Color(0xFFFF4444)
                  : _FPC.border,
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: _FPC.primary.withOpacity(0.25),
            blurRadius: 12,
          ),
        ],
      ),
      child: Text(
        label,
        style: TextStyle(
          color: _state == _AuthState.success
              ? const Color(0xFF00FF00)
              : _state == _AuthState.failed || _state == _AuthState.unavailable
                  ? const Color(0xFFFF4444)
                  : _FPC.primary,
          fontSize: 12,
          fontWeight: FontWeight.w800,
          fontFamily: 'Orbitron',
          letterSpacing: 2,
          shadows: const [Shadow(color: Colors.white, blurRadius: 10)],
        ),
      ),
    );
  }

  Widget _buildActionButtons() {
    if (_state == _AuthState.scanning || _state == _AuthState.success) {
      return const SizedBox.shrink();
    }
    if (_state != _AuthState.failed && _state != _AuthState.unavailable) {
      return const SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          GestureDetector(
            onTap: _authenticate,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF071827), Color(0xFF0B1024)],
                ),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: _FPC.primary.withOpacity(0.85), width: 1.4),
                boxShadow: [
                  BoxShadow(color: _FPC.primary.withOpacity(0.16), blurRadius: 24, spreadRadius: 1),
                ],
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.refresh_rounded, color: _FPC.primary, size: 18),
                  SizedBox(width: 10),
                  Text(
                    'COBA PEMINDAIAN LAGI',
                    style: TextStyle(
                      color: _FPC.primary,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          TextButton.icon(
            onPressed: _showSecurityDetails,
            icon: const Icon(Icons.verified_user_outlined, size: 17),
            label: const Text('DETAIL & DIAGNOSTIK KEAMANAN'),
            style: TextButton.styleFrom(
              foregroundColor: _FPC.textSub,
              textStyle: const TextStyle(fontSize: 10, letterSpacing: 1.0, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

}

// ═══════════════════════════════════════════════════════════════════
// PAINTER: RING BERPUTAR + PROGRESS ARC
// ═══════════════════════════════════════════════════════════════════
class _FingerprintRingPainter extends CustomPainter {
  final double rotation;
  final double progress;
  final Color  stateColor;

  _FingerprintRingPainter({
    required this.rotation,
    required this.progress,
    this.stateColor = Colors.white,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 4;

    // ─── 1. Ring putih berputar ───
    final sweepPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5
      ..strokeCap = StrokeCap.round
      ..shader = SweepGradient(
        transform: GradientRotation(rotation),
        colors: [
          Colors.transparent,
          stateColor,
          stateColor,
          Colors.transparent,
        ],
        stops: const [0.0, 0.3, 0.7, 1.0],
      ).createShader(Rect.fromCircle(center: center, radius: radius));

    canvas.drawCircle(center, radius, sweepPaint);

    // ─── 2. Glow ring ───
    final glowPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 8
      ..strokeCap = StrokeCap.round
      ..shader = SweepGradient(
        transform: GradientRotation(rotation),
        colors: [
          Colors.transparent,
          stateColor.withOpacity(0.7),
          Colors.transparent,
        ],
        stops: const [0.0, 0.5, 1.0],
      ).createShader(Rect.fromCircle(center: center, radius: radius))
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);

    canvas.drawCircle(center, radius, glowPaint);

    // ─── 3. Track background ───
    final trackPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5
      ..color = stateColor.withOpacity(0.15);
    canvas.drawCircle(center, radius - 10, trackPaint);

    // ─── 4. Progress arc ───
    if (progress > 0) {
      final progressPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 6
        ..strokeCap = StrokeCap.round
        ..color = stateColor;

      final rect = Rect.fromCircle(center: center, radius: radius - 10);
      canvas.drawArc(rect, -math.pi / 2, progress * 2 * math.pi, false,
          progressPaint);

      // ─── 5. Glow progress ───
      final glowProgress = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 10
        ..strokeCap = StrokeCap.round
        ..color = stateColor.withOpacity(0.5)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);

      canvas.drawArc(rect, -math.pi / 2, progress * 2 * math.pi, false,
          glowProgress);

      // ─── 6. Titik ujung progress ───
      final endAngle = -math.pi / 2 + progress * 2 * math.pi;
      final dotX = center.dx + (radius - 10) * math.cos(endAngle);
      final dotY = center.dy + (radius - 10) * math.sin(endAngle);

      canvas.drawCircle(
        Offset(dotX, dotY),
        8,
        Paint()
          ..color = stateColor.withOpacity(0.5)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
      );
      canvas.drawCircle(
          Offset(dotX, dotY), 4, Paint()..color = stateColor);
      canvas.drawCircle(
          Offset(dotX, dotY), 2, Paint()..color = Colors.black);
    }

    // ─── 7. Partikel titik berputar ───
    if (progress > 0.1) {
      final dotPaint = Paint()..color = stateColor.withOpacity(0.9);
      final dots = (progress * 12).round();
      for (int i = 0; i < dots; i++) {
        final angle = (i / dots) * 2 * math.pi + rotation;
        final pos = Offset(
          center.dx + (radius + 8) * math.cos(angle),
          center.dy + (radius + 8) * math.sin(angle),
        );
        canvas.drawCircle(pos, 2, dotPaint);
      }
    }
  }

  @override
  bool shouldRepaint(_FingerprintRingPainter old) =>
      old.rotation != rotation ||
      old.progress != progress ||
      old.stateColor != stateColor;
}

class _FingerprintHoloPainter extends CustomPainter {
  final double rotation;
  final double scan;
  final bool active;
  final Color color;

  const _FingerprintHoloPainter({
    required this.rotation,
    required this.scan,
    required this.active,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width * 0.47;
    final opacity = active ? 0.9 : 0.42;

    // Dua arc holografik yang bergerak berlawanan arah.
    final arcPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round
      ..color = color.withOpacity(opacity);
    final arcRect = Rect.fromCircle(center: center, radius: radius);
    canvas.drawArc(arcRect, rotation, math.pi * 0.42, false, arcPaint);
    canvas.drawArc(arcRect, -rotation * 0.72 + math.pi, math.pi * 0.27, false,
        arcPaint..color = const Color(0xFFB59BFF).withOpacity(opacity * 0.8));

    // Titik energi yang mengorbit pada empat kuadran.
    for (int i = 0; i < 8; i++) {
      final angle = rotation * (i.isEven ? 1 : -0.72) +
          i * math.pi / 4;
      final point = Offset(
        center.dx + radius * math.cos(angle),
        center.dy + radius * math.sin(angle),
      );
      canvas.drawCircle(
        point,
        i.isEven ? 2.8 : 1.8,
        Paint()
          ..color = color.withOpacity(opacity)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3),
      );
      canvas.drawCircle(point, 1.2, Paint()..color = Colors.white.withOpacity(opacity));
    }

    // Garis pemindai bergerak di dalam lingkaran saat autentikasi aktif.
    if (active) {
      final innerRadius = size.width * 0.34;
      final scanY = center.dy - innerRadius + (scan * 2 * innerRadius);
      final clip = Path()
        ..addOval(Rect.fromCircle(center: center, radius: innerRadius));
      canvas.save();
      canvas.clipPath(clip);
      final beam = Paint()
        ..shader = LinearGradient(
          colors: [
            color.withOpacity(0.0),
            color.withOpacity(0.28),
            Colors.white.withOpacity(0.72),
            color.withOpacity(0.28),
            color.withOpacity(0.0),
          ],
        ).createShader(Rect.fromLTWH(0, scanY - 5, size.width, 10));
      canvas.drawRect(Rect.fromLTWH(0, scanY - 5, size.width, 10), beam);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(_FingerprintHoloPainter old) =>
      old.rotation != rotation || old.scan != scan ||
      old.active != active || old.color != color;
}

// ═══════════════════════════════════════════════════════════════════
// PAINTER: GRID PUTIH
// ═══════════════════════════════════════════════════════════════════
class _FpGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = _FPC.border.withOpacity(0.10)
      ..strokeWidth = 0.5;
    const step = 45.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

// ═══════════════════════════════════════════════════════════════════
// WIDGET INLINE: TEKAN & TAHAN (tidak berubah — untuk penggunaan lain)
// ═══════════════════════════════════════════════════════════════════
class FingerprintVerifyWidget extends StatefulWidget {
  final VoidCallback onVerified;
  final double size;
  final Duration duration;

  const FingerprintVerifyWidget({
    super.key,
    required this.onVerified,
    this.size = 220,
    this.duration = const Duration(milliseconds: 1800),
  });

  @override
  State<FingerprintVerifyWidget> createState() =>
      _FingerprintVerifyWidgetState();
}

class _FingerprintVerifyWidgetState extends State<FingerprintVerifyWidget>
    with TickerProviderStateMixin {
  double _progress = 0.0;
  bool _pressing = false;
  bool _verified = false;
  Timer? _timer;
  DateTime? _pressStartTime;
  int _lastPercent = 0;

  late AnimationController _glowController;
  late AnimationController _rotateController;
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _rotateController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3000),
    )..repeat();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _glowController.dispose();
    _rotateController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  void _startPress() {
    if (_verified || _pressing) return;
    HapticFeedback.mediumImpact();
    _pressStartTime = DateTime.now();
    setState(() {
      _pressing = true;
      _progress = 0.0;
      _lastPercent = 0;
    });
    if (!_pulseController.isAnimating) _pulseController.repeat(reverse: true);
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (t) {
      if (!mounted || !_pressing || _verified) { t.cancel(); return; }
      final elapsed = DateTime.now().difference(_pressStartTime!);
      final totalMs = widget.duration.inMilliseconds;
      final newProgress = (elapsed.inMilliseconds / totalMs).clamp(0.0, 1.0);
      final currentPercent = (newProgress * 100).toInt();
      if (currentPercent ~/ 10 > _lastPercent ~/ 10) HapticFeedback.selectionClick();
      _lastPercent = currentPercent;
      setState(() => _progress = newProgress);
      if (newProgress >= 1.0) { t.cancel(); _onComplete(); }
    });
  }

  void _endPress() {
    if (_verified) return;
    _timer?.cancel();
    _pressStartTime = null;
    if (_progress >= 1.0) return;
    if (_progress > 0.0) {
      HapticFeedback.lightImpact();
      final start = _progress;
      const resetDurationMs = 200;
      final startTime = DateTime.now();
      Timer.periodic(const Duration(milliseconds: 16), (t) {
        if (!mounted) { t.cancel(); return; }
        final elapsed = DateTime.now().difference(startTime).inMilliseconds;
        final factor = (1.0 - (elapsed / resetDurationMs)).clamp(0.0, 1.0);
        setState(() => _progress = start * factor);
        if (elapsed >= resetDurationMs) {
          t.cancel();
          if (mounted) setState(() => _progress = 0.0);
        }
      });
    }
    if (mounted) setState(() => _pressing = false);
    _pulseController.stop();
    _pulseController.reset();
  }

  void _onComplete() {
    if (_verified) return;
    _verified = true;
    _pressing = false;
    HapticFeedback.heavyImpact();
    _pulseController.stop();
    setState(() => _progress = 1.0);
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) widget.onVerified();
    });
  }

  @override
  Widget build(BuildContext context) {
    final size = widget.size;
    return Listener(
      behavior: HitTestBehavior.opaque,
      onPointerDown: (_) => _startPress(),
      onPointerUp: (_) => _endPress(),
      onPointerCancel: (_) => _endPress(),
      child: AnimatedBuilder(
        animation: Listenable.merge([
          _glowController,
          _rotateController,
          _pulseController,
        ]),
        builder: (context, _) {
          final glow   = _glowController.value;
          final rotate = _rotateController.value;
          final pulse  = _pressing ? (0.9 + _pulseController.value * 0.15) : 1.0;
          return Transform.scale(
            scale: pulse,
            child: SizedBox(
              width: size,
              height: size,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: size,
                    height: size,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: _FPC.primary.withOpacity(
                              0.25 + glow * 0.35 + _progress * 0.4),
                          blurRadius: 30 + glow * 20 + _progress * 30,
                          spreadRadius: 2 + _progress * 4,
                        ),
                      ],
                    ),
                  ),
                  CustomPaint(
                    size: Size(size, size),
                    painter: _FingerprintRingPainter(
                      rotation: rotate * 2 * math.pi,
                      progress: _progress,
                    ),
                  ),
                  Container(
                    width: size - 20,
                    height: size - 20,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _FPC.card,
                      border: Border.all(
                        color: _FPC.border.withOpacity(
                            0.5 + glow * 0.4 + _progress * 0.5),
                        width: 2.5,
                      ),
                    ),
                  ),
                  Icon(
                    _verified ? Icons.check_rounded : Icons.fingerprint_rounded,
                    size: size * 0.4,
                    color: _FPC.primary,
                  ),
                  Positioned(
                    bottom: size * 0.12,
                    child: Text(
                      '${(_progress * 100).toInt()}%',
                      style: const TextStyle(
                        color: _FPC.primary,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                        shadows: [Shadow(color: Colors.white, blurRadius: 10)],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
