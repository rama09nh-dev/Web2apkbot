import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

/// User-selected background media shared by the dashboard picker and renderer.
class XyroxBackgroundMedia {
  final String path;
  final String type; // 'image' or 'video'
  const XyroxBackgroundMedia({required this.path, required this.type});
}

class XyroxBackgroundSelection {
  static const pathKey = 'xyroxone_custom_background_path';
  static const typeKey = 'xyroxone_custom_background_type';
  static final ValueNotifier<XyroxBackgroundMedia?> selected =
      ValueNotifier<XyroxBackgroundMedia?>(null);

  static Future<void> set(String path, String type) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(pathKey, path);
    await prefs.setString(typeKey, type);
    selected.value = XyroxBackgroundMedia(path: path, type: type!);
  }

  static Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(pathKey);
    await prefs.remove(typeKey);
    selected.value = null;
  }
}

/// Muted dashboard ambience. Custom photos/videos are stored in app documents,
/// so they remain available after the gallery picker returns or the app restarts.
class GlobalBackgroundVideo extends StatefulWidget {
  final Widget child;
  const GlobalBackgroundVideo({super.key, required this.child});

  @override
  State<GlobalBackgroundVideo> createState() => _GlobalBackgroundVideoState();
}

class _GlobalBackgroundVideoState extends State<GlobalBackgroundVideo>
    with WidgetsBindingObserver {
  VideoPlayerController? _controller;
  Timer? _watchdog;
  bool _ready = false;
  bool _foreground = true;
  bool _recovering = false;
  String? _customPath;
  String? _customType;
  DateTime? _bufferingSince;
  int _loadGeneration = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    XyroxBackgroundSelection.selected.addListener(_onSelectionChanged);
    _loadSavedSelection();
  }

  Future<void> _loadSavedSelection() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final path = prefs.getString(XyroxBackgroundSelection.pathKey);
      final type = prefs.getString(XyroxBackgroundSelection.typeKey);
      if (path != null && (type == 'image' || type == 'video') &&
          await File(path).exists()) {
        XyroxBackgroundSelection.selected.value =
            XyroxBackgroundMedia(path: path, type: type!);
      } else {
        await XyroxBackgroundSelection.clear();
        await _applySelection(null);
      }
    } catch (_) {
      await _applySelection(null);
    }
  }

  void _onSelectionChanged() {
    unawaited(_applySelection(XyroxBackgroundSelection.selected.value));
  }

  Future<void> _applySelection(XyroxBackgroundMedia? media) async {
    final generation = ++_loadGeneration;
    _watchdog?.cancel();
    _bufferingSince = null;
    _customPath = media?.path;
    _customType = media?.type;

    if (media != null && !await File(media.path).exists()) {
      _customPath = null;
      _customType = null;
      if (mounted) setState(() {});
      media = null;
    }

    if (media?.type == 'image') {
      final old = _controller;
      _controller = null;
      _ready = false;
      if (mounted) setState(() {});
      if (old != null) await old.dispose();
      return;
    }

    await _startVideo(media?.path, generation: generation);
  }

  Future<void> _startVideo(String? filePath, {required int generation}) async {
    final old = _controller;
    _controller = null;
    _ready = false;
    if (mounted) setState(() {});
    if (old != null) {
      try { await old.dispose(); } catch (_) {}
    }
    if (!mounted || generation != _loadGeneration) return;

    final controller = filePath == null
        ? VideoPlayerController.asset(
            'assets/videos/xyroxone_global_background.mp4',
            videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
          )
        : VideoPlayerController.file(
            File(filePath),
            videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
          );
    _controller = controller;
    try {
      await controller.initialize();
      if (!mounted || generation != _loadGeneration) {
        await controller.dispose();
        return;
      }
      await controller.setVolume(0.0);
      await controller.setLooping(true);
      _ready = true;
      if (mounted) setState(() {});
      if (_foreground) await controller.play();
      _watchdog = Timer.periodic(const Duration(seconds: 3), (_) {
        if (_foreground && mounted) _ensurePlaying();
      });
    } catch (_) {
      _ready = false;
      if (identical(_controller, controller)) _controller = null;
      try { await controller.dispose(); } catch (_) {}
      if (mounted) setState(() {});
      // Invalid/unsupported custom video falls back to the bundled background.
      if (filePath != null && mounted && generation == _loadGeneration) {
        _customPath = null;
        _customType = null;
        await XyroxBackgroundSelection.clear();
        await _startVideo(null, generation: ++_loadGeneration);
      }
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _foreground = state == AppLifecycleState.resumed;
    if (!_ready) return;
    if (_foreground) {
      _ensurePlaying();
    } else if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive ||
        state == AppLifecycleState.hidden ||
        state == AppLifecycleState.detached) {
      _pauseVideo();
    }
  }

  Future<void> _ensurePlaying() async {
    final controller = _controller;
    if (!_ready || !_foreground || !mounted || _recovering || controller == null) return;
    if (!controller.value.isInitialized) return;
    final value = controller.value;
    final now = DateTime.now();
    if (value.isBuffering) {
      _bufferingSince ??= now;
      if (now.difference(_bufferingSince!) < const Duration(seconds: 12)) return;
    } else {
      _bufferingSince = null;
    }
    final stalled = _bufferingSince != null &&
        now.difference(_bufferingSince!) >= const Duration(seconds: 12);
    if (value.isPlaying && !stalled) return;
    _recovering = true;
    try {
      if (stalled) {
        await controller.pause();
        await controller.seekTo(Duration.zero);
        _bufferingSince = null;
      } else if (value.hasError ||
          (value.duration > Duration.zero &&
           value.position >= value.duration - const Duration(milliseconds: 250))) {
        await controller.seekTo(Duration.zero);
      }
      await controller.setVolume(0.0);
      await controller.play();
    } catch (_) {
      // Retry transient decoder stalls on the next watchdog tick.
    } finally {
      _recovering = false;
    }
  }

  Future<void> _pauseVideo() async {
    final controller = _controller;
    try {
      if (controller != null && controller.value.isInitialized && controller.value.isPlaying) {
        await controller.pause();
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    XyroxBackgroundSelection.selected.removeListener(_onSelectionChanged);
    _watchdog?.cancel();
    _controller?.dispose();
    super.dispose();
  }

  Widget _buildBackground() {
    if (_customType == 'image' && _customPath != null) {
      return Image.file(
        File(_customPath!),
        fit: BoxFit.cover,
        width: double.infinity,
        height: double.infinity,
        errorBuilder: (_, __, ___) => const ColoredBox(color: Color(0xFF050A16)),
      );
    }
    final controller = _controller;
    if (_ready && controller != null && controller.value.isInitialized) {
      return FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: controller.value.size.width,
          height: controller.value.size.height,
          child: VideoPlayer(controller),
        ),
      );
    }
    return const ColoredBox(color: Color(0xFF050A16));
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Positioned.fill(child: IgnorePointer(child: _buildBackground())),
        // UI stays above the media; custom video is always muted.
        Positioned.fill(child: widget.child),
      ],
    );
  }
}
