import 'dart:async';

import 'package:audio_service/audio_service.dart';
import 'package:just_audio/just_audio.dart';

/// Android media-session/foreground-service owner for XyroxOne soundtrack.
/// The handler intentionally outlives dashboard routes and Flutter UI lifecycle.
class XyroxAudioHandler extends BaseAudioHandler with SeekHandler {
  static XyroxAudioHandler? instance;
  final AudioPlayer _player = AudioPlayer();
  bool _sourceReady = false;
  double _volume = 0.38;

  XyroxAudioHandler() {
    instance = this;
    _player.playbackEventStream.listen((event) {
      _publishState();
    }, onError: (Object error, StackTrace stackTrace) {
      _publishState();
    });
    _player.playerStateStream.listen((_) => _publishState());
    mediaItem.add(const MediaItem(
      id: 'xyroxone-background-music',
      title: 'XyroxOne Background Music',
      artist: 'XyroxOne',
    ));
  }

  bool get isPlaying => _player.playing;
  Stream<bool> get playingStream => _player.playingStream;

  Future<void> startMusic() async {
    if (!_sourceReady) {
      await _player.setAsset('assets/audio/splash_music.mp3');
      await _player.setLoopMode(LoopMode.one);
      await _player.setVolume(_volume);
      _sourceReady = true;
    }
    if (!_player.playing) unawaited(_player.play());
    _publishState();
  }

  Future<void> setMusicVolume(double value) async {
    _volume = value.clamp(0.0, 1.0).toDouble();
    await _player.setVolume(_volume);
  }

  Future<void> _publishState() async {
    final playing = _player.playing;
    final processing = _player.processingState;
    playbackState.add(playbackState.value.copyWith(
      controls: <MediaControl>[
        if (playing) MediaControl.pause else MediaControl.play,
        MediaControl.stop,
      ],
      systemActions: const <MediaAction>{MediaAction.seek},
      androidCompactActionIndices: const <int>[0, 1],
      processingState: switch (processing) {
        ProcessingState.idle => AudioProcessingState.idle,
        ProcessingState.loading => AudioProcessingState.loading,
        ProcessingState.buffering => AudioProcessingState.buffering,
        ProcessingState.ready => AudioProcessingState.ready,
        ProcessingState.completed => AudioProcessingState.completed,
      },
      playing: playing,
      updatePosition: _player.position,
      bufferedPosition: _player.bufferedPosition,
      speed: _player.speed,
    ));
  }

  @override
  Future<void> play() async {
    await startMusic();
  }

  @override
  Future<void> pause() async {
    await _player.pause();
    await _publishState();
  }

  @override
  Future<void> stop() async {
    await _player.stop();
    await super.stop();
    await _publishState();
  }

  @override
  Future<void> seek(Duration position) => _player.seek(position);

}
