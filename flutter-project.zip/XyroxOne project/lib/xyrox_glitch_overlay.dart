import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

/// App-wide holographic atmosphere. Decorative only: it never intercepts input
/// and never changes authentication, routing, or feature behavior.
class XyroxGlitchOverlay extends StatefulWidget {
  final Widget child;

  const XyroxGlitchOverlay({super.key, required this.child});

  @override
  State<XyroxGlitchOverlay> createState() => _XyroxGlitchOverlayState();
}

class _XyroxGlitchOverlayState extends State<XyroxGlitchOverlay>
    with WidgetsBindingObserver {
  // A deliberately capped visual refresh avoids repainting the full-screen
  // decorative layer at the device's full 60/90/120 Hz refresh rate.
  final ValueNotifier<double> _progress = ValueNotifier<double>(0);
  Timer? _visualTimer;
  double _phase = 0;
  bool _motionAllowed = true;
  bool _appForeground = true;

  void _startVisualTimer() {
    _visualTimer?.cancel();
    if (!_motionAllowed || !_appForeground) return;
    _visualTimer = Timer.periodic(const Duration(milliseconds: 84), (_) {
      _phase = (_phase + 0.021) % 1.0;
      _progress.value = _phase;
    });
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _motionAllowed = !(MediaQuery.maybeOf(context)?.disableAnimations ?? false);
    if (_motionAllowed) {
      _startVisualTimer();
    } else {
      _visualTimer?.cancel();
      _visualTimer = null;
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _appForeground = state == AppLifecycleState.resumed;
    if (_appForeground) {
      _startVisualTimer();
    } else {
      _visualTimer?.cancel();
      _visualTimer = null;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _visualTimer?.cancel();
    _progress.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Respect the platform's reduced-motion / disable-animations preference.
    if (MediaQuery.maybeOf(context)?.disableAnimations ?? false) {
      return widget.child;
    }
    return Stack(
      fit: StackFit.expand,
      children: [
        // Explicitly pin the Navigator/page to the complete Flutter view.
        // This avoids a narrow child layout leaving a black strip on the right
        // on devices using unusual display/window sizing.
        Positioned.fill(child: widget.child),
        Positioned.fill(
          child: IgnorePointer(
            child: ExcludeSemantics(
              child: RepaintBoundary(
                child: ValueListenableBuilder<double>(
                  valueListenable: _progress,
                  builder: (context, progress, child) => CustomPaint(
                    painter: _HolographicGlitchPainter(progress),
                    isComplex: false,
                    willChange: true,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _HolographicGlitchPainter extends CustomPainter {
  final double progress;

  const _HolographicGlitchPainter(this.progress);

  static const Color _cyan = Color(0xFF00D9FF);
  static const Color _blue = Color(0xFF287BFF);
  static const Color _violet = Color(0xFF8B35FF);
  static const Color _magenta = Color(0xFFD34BFF);

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width <= 0 || size.height <= 0) return;

    final w = size.width;
    final h = size.height;
    final phase = (progress * 12).floor();
    final cycle = (progress * 3.0) % 1.0;

    // A restrained radial energy bloom anchors the visual identity without
    // covering text or adding expensive blur layers.
    final coreCenter = Offset(w * 0.5, h * 0.43);
    final coreRadius = math.min(w, h) * 0.43;
    final corePulse = 0.5 + 0.5 * math.sin(progress * math.pi * 2);
    final corePaint = Paint()
      ..shader = RadialGradient(
        colors: [
          _blue.withOpacity(0.018 + corePulse * 0.012),
          _violet.withOpacity(0.012),
          Colors.transparent,
        ],
        stops: const [0.0, 0.58, 1.0],
      ).createShader(Rect.fromCircle(center: coreCenter, radius: coreRadius));
    canvas.drawCircle(coreCenter, coreRadius, corePaint);

    // Low-cost orbital nodes and connecting lines add a holographic HUD feel.
    final nodePaint = Paint()..color = _blue.withOpacity(0.10);
    final nodeLinePaint = Paint()
      ..color = _violet.withOpacity(0.065)
      ..strokeWidth = 0.8;
    final nodes = <Offset>[
      Offset(w * 0.12, h * 0.31),
      Offset(w * 0.20, h * 0.36),
      Offset(w * 0.84, h * 0.29),
      Offset(w * 0.91, h * 0.34),
      Offset(w * 0.14, h * 0.77),
      Offset(w * 0.22, h * 0.73),
      Offset(w * 0.82, h * 0.76),
      Offset(w * 0.90, h * 0.71),
    ];
    for (var i = 0; i < nodes.length; i += 2) {
      canvas.drawLine(nodes[i], nodes[i + 1], nodeLinePaint);
      canvas.drawCircle(nodes[i], 1.7, nodePaint);
      canvas.drawCircle(nodes[i + 1], 1.7, nodePaint);
    }

    // Low-contrast scanlines provide texture without washing out text.
    final scanPaint = Paint()..color = _cyan.withOpacity(0.012);
    // Sparse scanlines keep the cyber texture while avoiding hundreds of
    // tiny draw calls on tall phone screens.
    for (double y = (progress * 16) % 16; y < h; y += 16) {
      canvas.drawRect(Rect.fromLTWH(0, y, w, 0.45), scanPaint);
    }

    // A slim scan beam and a second, dimmer spectral echo.
    final scanY = (progress * h * 1.35) % h;
    canvas.drawRect(
      Rect.fromLTWH(0, scanY, w, 1.25),
      Paint()..color = _cyan.withOpacity(0.075),
    );
    canvas.drawRect(
      Rect.fromLTWH(0, (scanY + h * 0.37) % h, w, 0.7),
      Paint()..color = _violet.withOpacity(0.055),
    );

    // Corner HUD brackets: faint enough to keep all controls readable.
    final hud = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = _blue.withOpacity(0.20);
    const inset = 10.0;
    const arm = 18.0;
    final corners = Path()
      ..moveTo(inset, inset + arm)
      ..lineTo(inset, inset)
      ..lineTo(inset + arm, inset)
      ..moveTo(w - inset - arm, inset)
      ..lineTo(w - inset, inset)
      ..lineTo(w - inset, inset + arm)
      ..moveTo(inset, h - inset - arm)
      ..lineTo(inset, h - inset)
      ..lineTo(inset + arm, h - inset)
      ..moveTo(w - inset - arm, h - inset)
      ..lineTo(w - inset, h - inset)
      ..lineTo(w - inset, h - inset - arm);
    canvas.drawPath(corners, hud);

    // Circuit traces stay near the edges so content remains unobstructed.
    final trace = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = _cyan.withOpacity(0.085);
    final circuit = Path()
      ..moveTo(0, h * 0.18)
      ..lineTo(w * 0.035, h * 0.18)
      ..lineTo(w * 0.055, h * 0.20)
      ..lineTo(w * 0.055, h * 0.24)
      ..moveTo(w, h * 0.72)
      ..lineTo(w * 0.965, h * 0.72)
      ..lineTo(w * 0.945, h * 0.70)
      ..lineTo(w * 0.945, h * 0.66);
    canvas.drawPath(circuit, trace);
    canvas.drawCircle(Offset(w * 0.055, h * 0.24), 2.1, Paint()..color = _cyan.withOpacity(0.22));
    canvas.drawCircle(Offset(w * 0.945, h * 0.66), 2.1, Paint()..color = _violet.withOpacity(0.24));

    // Maximum-intensity glitch bursts are brief and spaced out. The rest of
    // the cycle is deliberately calm to balance visual impact and battery use.
    final burst = _burstStrength(cycle);
    if (burst > 0) {
      final blockPaint = Paint()..style = PaintingStyle.fill;
      for (var i = 0; i < 7; i++) {
        final seed = (phase * 29 + i * 37 + 11) % 101;
        final y = (seed / 101) * h;
        final rawX = ((phase * 43 + i * 61) % 100) / 100 * w;
        final blockW = math.min(w * (0.08 + (i % 3) * 0.045), w - rawX).toDouble();
        if (blockW <= 0) continue;
        final height = 1.4 + (i % 3) * 1.25;
        final shift = math.sin(progress * math.pi * 2 + i * 1.7) * (5 + i * 1.6);
        final x = (rawX + shift).clamp(0.0, math.max(0.0, w - blockW)).toDouble();
        final color = i % 3 == 0 ? _magenta : (i.isEven ? _cyan : _violet);
        blockPaint.color = color.withOpacity((0.12 + (i % 2) * 0.08) * burst);
        canvas.drawRect(Rect.fromLTWH(x, y, blockW, height), blockPaint);
      }

      // Short digital tear bands make the maximum-glitch setting more visible
      // while keeping the effect transient and strictly decorative.
      for (var band = 0; band < 3; band++) {
        final tearY = (h * (0.16 + ((phase * 13 + band * 23) % 68) / 100))
            .clamp(0.0, math.max(0.0, h - 3.0)).toDouble();
        final tearShift = math.sin(progress * 31 + band * 2.4) * (8 + band * 5);
        final tearX = (w * (0.08 + band * 0.24) + tearShift)
            .clamp(0.0, math.max(0.0, w - w * 0.22)).toDouble();
        final tearColor = band.isEven ? _cyan : _magenta;
        canvas.drawRect(
          Rect.fromLTWH(tearX, tearY, w * (0.12 + band * 0.035), 1.0 + band * 0.6),
          Paint()..color = tearColor.withOpacity(0.22 * burst),
        );
      }

      // RGB-split echoes appear only during a burst, never as a permanent blur.
      final echoY = h * (0.22 + ((phase * 17) % 53) / 100);
      final echoH = 2.0 + burst * 2.0;
      canvas.drawRect(
        Rect.fromLTWH(0, echoY, w * 0.31, echoH),
        Paint()..color = _magenta.withOpacity(0.10 * burst),
      );
      canvas.drawRect(
        Rect.fromLTWH(w * 0.045, echoY + echoH + 1, w * 0.24, 1.2),
        Paint()..color = _cyan.withOpacity(0.17 * burst),
      );
      canvas.drawRect(
        Rect.fromLTWH(w * 0.72, echoY - 2, w * 0.19, 1.5),
        Paint()..color = _blue.withOpacity(0.15 * burst),
      );
    }
  }

  double _burstStrength(double cycle) {
    // Three compact bursts in each cycle; no rapid full-screen flashing.
    const centers = <double>[0.12, 0.48, 0.82];
    var strength = 0.0;
    for (final center in centers) {
      final distance = (cycle - center).abs();
      final wrapped = math.min(distance, 1 - distance).toDouble();
      if (wrapped < 0.035) {
        final local = 1 - wrapped / 0.035;
        strength = math.max(strength, local * local).toDouble();
      }
    }
    return strength;
  }

  @override
  bool shouldRepaint(covariant _HolographicGlitchPainter oldDelegate) =>
      oldDelegate.progress != progress;
}
