# XyroxOne 2.03.3 — Cyber Glass / Neo Minimal / Holographic

## Visual polish
- Unified Material 3 styling for app bars, cards, inputs, dialogs, bottom sheets, buttons, navigation, chips, switches, checkboxes, radio controls, sliders, progress indicators, menus, and tooltips.
- Kept Orbitron for display headings and Roboto for readable content text.
- Removed unintended Material 3 tonal surface overlays from app bars and cards.
- Kept the login and splash glass panels restrained, reducing blur cost on mid-range devices.
- Kept the dashboard app bar translucent over the independent background video.
- Reduced global holographic scanline/beam intensity and capped its refresh rate.
- Pauses the decorative overlay timer while the app is backgrounded or the device requests reduced motion.
- Kept the splash video fully visible in portrait layouts (contain instead of crop).

## Stability fixes
- Removed the duplicate `textTheme` named argument from `ThemeData`, which prevented Dart compilation.
- Made the clamped text-scale value explicitly a `double` for `TextScaler.linear`.
- Made Firebase initialization failure non-fatal to app launch so the login screen can still open during a temporary Firebase outage. Firebase-backed features still require Firebase connectivity/configuration.
- Preserved the existing authentication, routing, API endpoints, feature logic, and XyroxOne identity.
- Kept background music as a real MP3 asset, separate from muted MP4 video assets.

## Validation status
- Dart source delimiter scan: passed for all 47 Dart files.
- Relative import existence scan: passed.
- ZIP integrity: checked after packaging.
- Media formats: MP3 and MP4 streams checked.
- `flutter analyze`, Flutter tests, release APK build, and physical-device visual/audio testing remain outstanding because the Flutter SDK is not available in this environment.
