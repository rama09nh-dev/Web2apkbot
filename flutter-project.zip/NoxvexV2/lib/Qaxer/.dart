class Api {
  static const String api = "http://omhcserver.mbudhost.biz.id:13083";
}